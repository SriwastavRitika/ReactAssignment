import React, { Component } from 'react';

const TableBody = props => {
    const rows = props.characterData.map((row, index) => {
        return (

            <tr key={index}>
                <td>{row.name}</td>
                <td>{row.address}</td>
                <td>{row.city}</td>
                <td>{row.state}</td>
                <td>{row.postal_code}</td>
                <td>{row.latitude}</td>
                <td>{row.longitude}</td>
                <td>{row.stars}</td>
                <td>{row.review_count}</td>
                <td>{row.categories}</td>


                <td>
                    <button onClick={() => props.removeCharacter(index)} style={{ backgroundColor: "lightblue", fontSize: "1px" }}>Delete</button>
                </td>
            </tr>
        )
    })

    return <tbody>{rows}</tbody>
}
export default TableBody;