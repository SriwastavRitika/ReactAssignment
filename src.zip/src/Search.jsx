import React, { Component } from 'react';

const Search = () => {
    return (
        <input type="text" value={this.StaticRange.value} />
    );
}
export default Search;
