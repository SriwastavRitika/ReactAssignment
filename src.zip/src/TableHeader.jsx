import React, { Component } from 'react';


const TableHeader = () => {
    return (
        <thead>
            <tr style={{ backgroundColor: "lightblue" }}>
                <th>name</th>
                <th>address</th>
                <th>city</th>
                <th>state</th>
                <th>postal_code</th>
                <th>latitude</th>
                <th>longitude</th>
                <th>stars</th>
                <th>review_count</th>
                <th>categories</th>
            </tr>
        </thead>
    )
}
export default TableHeader;